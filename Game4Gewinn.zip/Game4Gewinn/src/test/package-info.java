/**
 * This package contains all tests for package model in Game4Gewinn.
 * This test check if the methods and all functions work well.
 * @author Yohanes Kirana
 */
package test;